# GOLF GCP Setup

## 1. Install required software

On Ubuntu/Debian:

```bash
sudo apt update
sudo apt upgrade -y

sudo apt install -y git nginx curl
```

Install Node.js 20:

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
```

Verify:

```bash
node -v
npm -v
```

Install PM2:

```bash
sudo npm install -g pm2
pm2 -v
```

## 2. Clone the repository

```bash
cd ~
git clone https://github.com/sclary2001/GOLF.git
cd GOLF
```

Install dependencies:

```bash
npm ci
```

## 3. Test the application

```bash
npm start
```

In another terminal:

```bash
curl http://127.0.0.1:3000/api/health
```

Stop the foreground process with `Ctrl+C`.

## 4. Start with PM2

```bash
pm2 start ecosystem.config.js --env production
pm2 save
pm2 startup
```

Run the command printed by `pm2 startup`, then:

```bash
pm2 save
pm2 status
```

## 5. Configure Nginx

Edit:

```bash
nano nginx/golf.conf
```

Replace:

```text
YOUR_GCP_SUBDOMAIN_HERE
```

with the assigned production subdomain.

Then:

```bash
sudo cp nginx/golf.conf /etc/nginx/sites-available/golf
sudo ln -s /etc/nginx/sites-available/golf /etc/nginx/sites-enabled/golf
sudo nginx -t
sudo systemctl reload nginx
```

## 6. Configure DNS

Create an A record for the assigned production subdomain pointing to the GCP VM's external IP.

## 7. Enable HTTPS

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d YOUR_GCP_SUBDOMAIN_HERE
sudo certbot renew --dry-run
```

## 8. GitHub Actions

In the GitHub repository, add:

```text
GCP_HOST = GCP VM external IP
GCP_USER = Linux username
GCP_SSH_KEY = private SSH key used by GitHub Actions
```

Never put these secret values in source code.

Pushes to `main` will run `.github/workflows/deploy.yml`.
