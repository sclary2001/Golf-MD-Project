async function checkHealth() {
  try {
    const response = await fetch("/api/health");
    if (!response.ok) throw new Error("Health check failed");
    console.log("GOLF application is online.");
  } catch (error) {
    console.error(error);
  }
}

checkHealth();
