# GOLF

Full-stack CI/CD infrastructure project.

See [`docs/README.md`](docs/README.md) for the project landing page and grading dashboard.

## Local development

```bash
npm install
npm start
```

Then open:

```text
http://localhost:3000
```
