module.exports = {
  apps: [
    {
      name: "golf",
      script: "./server/server.js",
      instances: 1,
      exec_mode: "fork",
      autorestart: true,
      watch: false,
      max_memory_restart: "250M",
      env: {
        NODE_ENV: "production",
        PORT: 3000
      }
    }
  ]
};
