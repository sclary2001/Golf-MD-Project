# GOLF Infrastructure Project
> Full-stack application with automated DEV and PROD deployment infrastructure.

### authorship + version

`@sclary2001` | `2026-09-14` | `GOLF`

### deployments, codebase, & repo features

| resource | link |
|---|---|
| PROD codebase | [`main`](https://github.com/sclary2001/GOLF/tree/main) |
| PROD server | `GCP_PROD_URL_HERE` |
| DEV codebase | [`dev`](https://github.com/sclary2001/GOLF/tree/dev) |
| DEV server | `RENDER_DEV_URL_HERE` |
| docs | [`docs/`](https://github.com/sclary2001/GOLF/tree/main/docs) |
| published docs | `GITHUB_PAGES_URL_HERE` |
| CI/CD workflow | [`deploy.yml`](https://github.com/sclary2001/GOLF/blob/main/.github/workflows/deploy.yml) |
| successful PROD deployment | `SUCCESSFUL_GITHUB_ACTION_URL_HERE` |
| resolved GOLF issue | `GOLF_ISSUE_URL_HERE` |

### user story

- **As a** burgeoning full-stack developer,
- **I want** a CI/CD infrastructure
- **so that** I can develop locally, manage my code in GitHub, and
  automatically deploy changes to DEV and PROD environments.

### narrative

This project demonstrates a full-stack development and deployment workflow using GitHub, Render, and Google Cloud Platform. The application is developed locally and pushed to the `dev` branch for automatic deployment to the Render DEV environment, while changes merged into `main` trigger GitHub Actions to deploy the production application to a GCP virtual machine. Nginx, PM2, HTTPS, and Node.js/Express are used to provide a reliable production environment.

### architecture

```text
LOCAL
  │
  ▼
GitHub
  │
  ├── dev  ──► Render ─────────────► DEV
  │
  └── main ──► GitHub Actions ─────► GCP ──► Nginx ──► PM2 ──► PROD
```

### stack

`HTML/CSS/JS` | `Node.js` | `Express` | `Git/GitHub` | `Render` |
`GCP` | `Linux` | `Nginx` | `PM2` | `Certbot` | `GitHub Actions`

### project structure

```text
GOLF/
├── .github/
│   └── workflows/
│       └── deploy.yml
├── docs/
│   └── README.md
├── public/
│   ├── index.html
│   ├── css/
│   │   └── styles.css
│   ├── js/
│   │   └── app.js
│   └── assets/
├── server/
│   ├── server.js
│   └── package.json
├── .gitignore
├── package.json
└── README.md
```

### GCP

external IP: `GCP_EXTERNAL_IP_HERE`Linux user: `GCP_LINUX_USERNAME_HERE`instructor SSH public key installed: `yes`

### grading checkpoints

- [x] Repository uses `public/` and `server/`
- [x] `node_modules/` is excluded from Git
- [ ] `dev` branch automatically deploys to Render DEV
- [ ] `main` branch triggers GitHub Actions
- [ ] GitHub Actions deploys production to GCP
- [ ] PROD uses assigned subdomain
- [ ] PROD uses HTTPS
- [ ] Nginx reverse proxy is configured
- [ ] PM2 is running the Node.js application
- [ ] Successful PROD GitHub Action is documented above
- [ ] A real GOLF problem is documented in a closed GitHub Issue
- [ ] GCP VM remains running for grading

### security

No passwords, private SSH keys, GitHub tokens, repository secrets, `.env` values, or other sensitive credentials are stored in this repository.

### GOLF issue

A real deployment or infrastructure problem encountered during development will be documented in a GitHub Issue and resolved before submission.

### production verification

Production will be verified after a successful GitHub Actions deployment. The deployed change must be visible on the production server and the application must be accessible through the assigned HTTPS subdomain.

### deployment configuration

#### Render DEV

Create a Render Web Service from the repository with:

```text
Branch: dev
Build Command: npm ci
Start Command: npm start
```

Set:

```text
NODE_ENV=development
```

The included `render.yaml` can also be used as the Render configuration.

#### GCP PROD

The GCP VM should have Node.js 20+, Git, Nginx, and PM2 installed.

Install PM2 with:

```bash
sudo npm install -g pm2
```

The production application runs on:

```text
127.0.0.1:3000
```

Nginx forwards public HTTPS traffic to the Node.js application.

Copy the Nginx configuration:

```bash
sudo cp nginx/golf.conf /etc/nginx/sites-available/golf
sudo ln -s /etc/nginx/sites-available/golf /etc/nginx/sites-enabled/golf
sudo nginx -t
sudo systemctl reload nginx
```

Replace `YOUR_GCP_SUBDOMAIN_HERE` in `nginx/golf.conf` with the assigned production subdomain.

#### HTTPS

After DNS points the assigned subdomain to the GCP VM, install Certbot and obtain the certificate:

```bash
sudo apt update
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d YOUR_GCP_SUBDOMAIN_HERE
```

Test renewal:

```bash
sudo certbot renew --dry-run
```

#### GitHub Actions secrets

Add these repository secrets in GitHub:

```text
GCP_HOST
GCP_USER
GCP_SSH_KEY
```

Do not commit the private SSH key or any secret values to the repository.
